# ZIPFS TEST

This file is part of a comprehensive test of the `zipFS` struct.
